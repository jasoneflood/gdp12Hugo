---
title: "Visualization & Insights Lab"
weight: 50
chapter: true
pre: "<b>5. </b>"
---

In this `Immersion Day` lab, you will learn about the capabilities of IBM Cognos Analytics on AWS Cloud infrastructure. The intent of this lab is to bring best of both IBM and AWS technologies together i.e., IaaS from AWS and best of breed analytics from IBM Cognos.
