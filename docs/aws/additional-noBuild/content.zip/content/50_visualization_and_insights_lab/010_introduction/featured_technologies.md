---
title: "Featured technologies of this Lab are listed below"
weight: 35
chapter: true
draft: false
pre: "<b>C. </b>"
---

* [Analytics](https://developer.ibm.com/code/technologies/analytics/): Analytics delivers the value of data for the enterprise.
* [Artificial Intelligence](https://developer.ibm.com/technologies/artificial-intelligence/): Any system which can mimic cognitive functions that humans associate with the human mind, such as learning and problem solving.
* [Databases](https://developer.ibm.com/technologies/databases): Store and manage collections of relational database management system (RDBMS).
