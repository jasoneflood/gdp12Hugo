---
title: "Watch the Video"
weight: 65
chapter: true
draft: false
pre: "<b>F. </b>"
---

### Lab-3 Demo Video

{{< rawhtml >}}

<video width=100% controls autoplay>
    <source src="/videos/lab3-demo.mp4" type="video/mp4">
    Your browser does not support the video tag.  
</video>

{{< /rawhtml >}}
