---
title: "Running the workshop at an AWS Event"
weight: 20
chapter: true
draft: false
---

<!--- # Running the workshop at an AWS Event --->

::alert[**Only complete this section if you are at an AWS hosted event (such as Immersion Day, or events hosted by an AWS employee). If you are running the workshop on your own, go to: [Start the workshop on your own](/10_getting_started/01_self_paced.html).**]

* [AWS Workshop Portal](/10_getting_started/02_aws_event/portal)
