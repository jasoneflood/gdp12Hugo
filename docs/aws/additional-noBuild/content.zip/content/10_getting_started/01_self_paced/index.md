---
title: "Running the workshop on your own"
weight: 10
chapter: true
draft: false
---

<!--- # Running the workshop on your own --->

::alert[**Only complete this section if you are running the workshop on your own. If you are at an AWS hosted event (such as Immersion Day), go to [Start the workshop at an AWS event](/10_getting_started/02_aws_event.html).**]

::children{depth=999}
