---
title: "Data Access and Governance Lab"
weight: 40
chapter: true
pre: "<b>4. </b>"
---

In this lab, you will learn about the capabilities of different IBM services such as IBM DataStage, Data Virtualization, Watson Knowledge Catalog on AWS Cloud infrastructure. The intent of this lab is to bring best of both IBM and AWS technologies together to create solid hybrid cloud data architecture and govern them.
