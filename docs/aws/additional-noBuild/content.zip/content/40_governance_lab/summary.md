---
title: "Summary"
weight: 30
chapter: true
draft: false
---

In this lab, we have learnt how to create connection between IBM Cloud Pak for Data and external data sources and how to ingest data from those data sources. We have also learned different strategies to integrate data using Data Virtualization and IBM DataStage.

In the Step 3, you have learned how to clean, reshape the data using IBM Data Refinery Flow and Finally you learned how to mask data using IBM Watson Knowledge Studio.
