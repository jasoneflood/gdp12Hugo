---
title: "IBM-AWS Better Together"
weight: 55
chapter: true
draft : false
pre: "<b>E. </b>"
---

![Better together](/static/images/30_governance_lab/better-together-data-lake.png?classes=shadow)
