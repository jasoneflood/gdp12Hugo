---
title: "Featured technologies in this Lab:"
weight: 35
chapter: true
draft: false
pre: "<b>C. </b>"
---

* [Data Lake](https://www.ibm.com/in-en/analytics/data-lake): A data lake is a centralized repository for managing extremely large data volumes.
* [Data Fabric](https://www.ibm.com/in-en/analytics/data-fabric/): A data fabric is an architectural approach to simplify data access in an organization to facilitate self-service data consumption.
* [Analytics](https://developer.ibm.com/technologies/analytics/): Uncover insights with data collection, organization, and analysis.
* [Data Management](https://developer.ibm.com/technologies/data-management/): Organize and maintain data processes through the information lifecycle.
* [Data Privacy](https://developer.ibm.com/technologies/data-privacy/): Using user data responsibly.
