---
title: "4. No Code Approach"
weight: 55
chapter: true
draft: false
---

In the No Code Approach you will learn how to build a classification model to predict Risk Index in Watson Studio's AutoAI. As a Developer you can build the model easily and quickly with just a few clicks on the AutoAI UI. Aditionally, you will also learn how to invoke the Watson Machine Learning model deployed on Cloud pak for Data in you applications running on Amazon Elastic Kubernetes Service (EKS).

#### The section is divided into following sub-sections:

::children{depth=999}
