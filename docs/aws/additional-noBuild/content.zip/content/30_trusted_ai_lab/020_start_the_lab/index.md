---
title: "Start the lab"
weight: 10
chapter: true
draft: false
pre: '<i class="fa fa-flask" aria-hidden="true"></i> '
---

## Steps

<!-- links don't work for some reason, look this over -->
::children{depth=999}
