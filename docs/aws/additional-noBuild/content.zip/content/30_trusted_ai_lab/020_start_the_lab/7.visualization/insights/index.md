---
title: "Insights from Cognos Embedded Dashboard"
weight: 20
chapter: false
draft: false
---

There are two tabs in the Dashboard Risk Index and Flanders Prediction, risk index and next 15 days prediction (Flanders) has been derived from Amazon SageMaker Model.

Risk Index tab contains details for all three regions as well as Risk Index details of each region.

![](/static/images/20_trusted_ai_lab/final_dashboard-1.2.png)

Flanders Prediction tab contains Flanders region Covid-19 data of Feb & March 2022 along with next 15 days prediction.

![](/static/images/20_trusted_ai_lab/final_dashboard-2.png)
