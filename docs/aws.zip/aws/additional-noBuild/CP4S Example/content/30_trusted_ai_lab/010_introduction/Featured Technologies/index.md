---
title: "Featured technologies of this Lab are listed below"
weight: 20
chapter: false
draft: false
pre: "<b>B. </b>"
---

* [Artificial Intelligence](https://developer.ibm.com/technologies/artificial-intelligence/): Any system which can mimic cognitive functions that humans associate with the human mind, such as learning and problem solving.

* [Data Science](https://developer.ibm.com/code/technologies/data-science/): Systems and scientific methods to analyze structured and unstructured data in order to extract knowledge and insights.

* [Analytics](https://developer.ibm.com/code/technologies/analytics/): Analytics delivers the value of data for the enterprise.

* [Python](https://www.python.org/): Python is a programming language that lets you work more quickly and integrate your systems more effectively.
