---
title: "Overview"
weight: 1
chapter: true
draft: false

---

Customers can have the data anywhere on any cloud which can be extracted and ingested into IBM Cloud Pak for Data for:

* Data pre-processing 

* Analysis

* Usecase formation

* Predictive model building

* Multiple deployment options

* Model monitoring

* Visualizations
