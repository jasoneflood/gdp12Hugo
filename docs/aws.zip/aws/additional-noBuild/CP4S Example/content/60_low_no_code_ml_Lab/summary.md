---
title: "Summary"
weight: 40
chapter: true
draft: false
---

Thank you for completing the Lab! Here is a quick summary of what you learnt in this Low code/no code lab:

- You learnt the code based approach to build classification and time-series models in IBM Cloud Pak for Data Watson Studio Jupyter notebooks.
- You learnt to visualize data in IBM Cloud Pak for Data Cognos Dashboard Embedded.
- You learnt the no code approach to build and compare different classification models in IBM Cloud Pak for Data AutoAI Experiments.
- You learnt how to invoke the Watson Machine Learning model deployed on IBM Cloud pak for Data in you applications running on Amazon Elastic Kubernetes Service (EKS).