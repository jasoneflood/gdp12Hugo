---
title: "Watch the Video"
weight: 65
chapter: true
draft: false
pre: "<b>F. </b>"
---


# Lab-2 Demo
<!-- https://ws-assets-us-east-1.s3.amazonaws.com/e64e20cf-684e-4a23-80e0-432892a54465/assets/ -->

:link[Video]{href = "/static/videos/lab_2_demo.mp4"}

{{< rawhtml >}}

<video src="/static/videos/lab_2_demo.mp4" controls="controls" style="max-width: 730px;">
</video>

{{< /rawhtml >}}