---
title: "Obtain an IBM Cloud Pak for Data trial license"
weight: 25
chapter: true
draft: false
pre: "<b>B. </b>"
---

<!--- Obtain an IBM Cloud Pak for Data trial license --->

Please use the following link to get access to a 60-day trial license for IBM Cloud Pak for Data, as you will need it to complete this workshop:
```sh
https://www.ibm.com/account/reg/us-en/signup?formid=urx-42212
```

![license](/static/images/00_getting_started/ibm-cp4d-trial-license.png)