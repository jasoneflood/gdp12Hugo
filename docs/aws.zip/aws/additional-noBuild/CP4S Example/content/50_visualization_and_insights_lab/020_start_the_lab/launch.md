---
title: "1. Launch IBM Cognos Analytics"
weight: 15
chapter: true
draft: false
---

1. Click on the navigation menu. Under the **Services** category, click on **Instances** as shown below.

![instances](/static/images/40_visualization_and_insights_lab/instances.png?classes=shadow)

2. Under **Instances** you will see **cognos-analytics-app**. Click on the three-dots as shown below and click on **Open**.

![cognos-analytics-app](/static/images/40_visualization_and_insights_lab/cognos-analytics-app.png?classes=shadow)

3. You will now see the **Cognos Analytics** service opened in a new tab as shown below.

![cognos-analytics-dashboard](/static/images/40_visualization_and_insights_lab/cognos-analytics-dashboard.png?classes=shadow)
