---
title: "Reference Architecture"
weight: 15
chapter: true
draft: false
pre: "<b>A. </b>"
---

![architecture](/static/images/40_visualization_and_insights_lab/architecture_lab3.png)

## Flow

1. Launch IBM Cognos Analytics
2. Connect AWS Aurora data source to IBM Cognos Analytics
3. Create the data modules on IBM Congos Analytics
4. Create and visualize IBM Cognos Analytics dashboard