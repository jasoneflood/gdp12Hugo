---
title: "Activity"
weight: 2
---

# IBM Guardium 12.1 – Comprehensive Data Security Platform
{{< video src="/video/test.mp4" width="800" height="450" >}}